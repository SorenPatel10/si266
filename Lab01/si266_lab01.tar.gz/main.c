#include "math.h"

int main() {
	print_math();

	return 0;
}
