#include <stdio.h>
#include "math.h"

void print_math() {
	printf(">> System Ready for Lab 1\n");
}
