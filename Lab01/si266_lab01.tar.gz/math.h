#ifndef MATH_H
#define MATH_H

void print_math(void);

#endif
